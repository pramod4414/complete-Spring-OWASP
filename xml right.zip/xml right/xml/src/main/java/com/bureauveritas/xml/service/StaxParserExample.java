package com.bureauveritas.xml.service;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import com.bureauveritas.xml.model.Employee;

public class StaxParserExample {
	public static void parser(String maliciousSample) throws Exception{
		
	}
	
}