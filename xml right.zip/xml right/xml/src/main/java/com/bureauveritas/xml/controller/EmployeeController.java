package com.bureauveritas.xml.controller;

import java.io.FileNotFoundException;
import java.io.StringReader;

import javax.xml.stream.XMLStreamException;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bureauveritas.xml.model.UserFile;
import com.bureauveritas.xml.service.StaxParserExample;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;


@Controller
public class EmployeeController {
		
	@RequestMapping("/")
	public String viewHomePage(Model model) {
	
		return "index";
	}
	
	@RequestMapping(value = "/login" ,method = RequestMethod.POST)
	public String register(@RequestParam("xmlfile") String valueOne) {
		try {
			String FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
            
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setFeature(FEATURE, true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new InputSource(new StringReader(valueOne)));
        Element root = doc.getDocumentElement();
    } catch (Exception e){
		e.printStackTrace();
	}
		return valueOne;
		
	}
	
	

}
