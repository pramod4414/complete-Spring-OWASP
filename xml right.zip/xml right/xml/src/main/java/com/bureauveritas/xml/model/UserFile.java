package com.bureauveritas.xml.model;

public class UserFile {
	private String xmlfile;

	
	
	public String getXmlfile() {
		return xmlfile;
	}

	public void setXmlfile(String xmlfile) {
		this.xmlfile = xmlfile;
	}

	

}
