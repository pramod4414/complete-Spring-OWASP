# Spring Security Login Tutorial

Tutorial / Full Information
https://medium.com/@gustavo.ponce.ch/spring-boot-spring-mvc-spring-security-mysql-a5d8545d837d

1. mvn clean
2. mvn clean install
3. Go to the target folder
4. java -jar login-0.0.1-SNAPSHOT.jar


- http://localhost:8080/registration
- http://localhost:8080/login
