package com.bv.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bv.connection.DBConnect;
import com.bv.loginmodel.User;

/**
 *  class  UserDaoImpl implements UserDao interface
 */
public class UserDaoImpl implements UserDao {
	
	@Override
	public boolean validate(User u) {
		boolean status = false;
		String username=u.getUsername();
		String password=u.getPassword();
		try
		{
	 String sql="select * from User where username = \'"+username+"\' and password = \'"+password+"\'";
	
	 System.out.println(sql);
	 
	 Connection connection =DBConnect.getConnection();
	 //   create statement performs takes the query towards database through network
	 Statement statement =connection.createStatement();
	 
	 ResultSet resultset = statement.executeQuery(sql);
	 while(resultset.next())
	 {
				status = true;
				System.out.println(resultset.getString(1));
				System.out.println(resultset.getString(2));
				
	 }
	 
		}
		catch(SQLException e)
		{
			
			e.printStackTrace();
		}
		return status;
		
		
		
		
	}
}
	
			/*boolean status = false;
			String sql = "select * from User "
					+ "where username = ? and password = ?";
			
			Connection con = DBConnect.getConnection();
			System.out.println(con);
			try {
				if(null != con) {
					PreparedStatement pstmt = con.prepareStatement(sql);
					System.out.println(pstmt);
					if(null != pstmt) {
						pstmt.setString(1, u.getUsername());
						pstmt.setString(2,u.getPassword());
						ResultSet rs = pstmt.executeQuery();
						
						if(rs.next())
						status = true;
					}
		
		
		
		
		
		
		
				}
			
				
			
		

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return status;
	}*/
		
		
		
		
		
		

