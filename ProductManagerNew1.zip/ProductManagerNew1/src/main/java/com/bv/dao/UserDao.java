package com.bv.dao;

import com.bv.loginmodel.User;
/**
 This is UserDao interface
 */
public interface UserDao {
	
	
	 /**
	  * This is simple validating method
	  * @param User u this is the reference variable of bean class
     */
	public boolean validate(User u);
	

}
