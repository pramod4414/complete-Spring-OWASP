package com.gpch.login;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping("/myurls")
public class MyRestController {

	
	@GetMapping(value="/firsturl")
	public ModelAndView getMyView() {
		return new ModelAndView("/admin/world");
	}
	
	
	@GetMapping(value="/secondurl")
	public ModelAndView getMyViewTwo() {
		return new ModelAndView("/admin/world");
	}
	
}
