package com.bureauveritas.xml.model;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/*
* Schema to hold multiple employee objects
*/
@XmlRootElement(name = "employees")
public class Employees {
    List<EmployeeData> employees;
    public List<EmployeeData> getEmployees() {
        return employees;
    }

    @XmlElement(name = "employeeData")
    public void setEmployees(List<EmployeeData> employees) {
        this.employees = employees;
    }

    public void add(EmployeeData employeeData) {
        if (this.employees == null) {
            this.employees = new ArrayList<EmployeeData>();
        }
        this.employees.add(employeeData);

    }
	
	@Override
    public String toString() {
		System.out.println("Our employee list after unmarshall is : ");
            StringBuffer str = new StringBuffer();
			for (EmployeeData emp : employees){
				str = str.append(emp.toString());
			}
			return str.toString();
    }

}