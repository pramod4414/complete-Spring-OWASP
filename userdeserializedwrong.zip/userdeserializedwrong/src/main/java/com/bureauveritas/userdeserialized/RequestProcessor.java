package com.bureauveritas.userdeserialized;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;



public class RequestProcessor {
	
	
	private static ObjectOutputStream serialize(Object obj) throws IOException {
		
	            User si = new User("piyu", "piyu", 25);
	            FileOutputStream fos = new FileOutputStream("user.ser");
	            ObjectOutputStream oos = new ObjectOutputStream(fos);
	            oos.writeObject(si);
	            oos.close();
	            fos.close();
	     
	            return oos;
		
		}
	
	
	private static Object deserialize(ObjectOutputStream serializedUser) throws IOException,
			ClassNotFoundException {
		
				User si=null ;
	       
	      
	            FileInputStream fis = new FileInputStream("user.ser");
	            ObjectInputStream ois = new ObjectInputStream(fis);
	            si = (User)ois.readObject();
	       
	           /* System.out.println(si.getName());
	            System.out. println(si.getPassword());
	            System.out.println(si.getAge());*/
	            
	            return si;
	            
	        }
		
		

	public static void main(String[] args) {
		try {
			
			// Serialize an User instance
			ObjectOutputStream serializedUser = serialize(new User("piyu", "piyu",25));

			
			// Serialize a File instance
			ObjectOutputStream serializedFile = serialize(new File("user.ser"));

			
			// Deserialize the User instance (legitimate use case)
			User user0 = (User) deserialize(serializedUser);
			
			System.out.println(user0.getName() + " has been deserialized.");

			
			// Deserialize the File instance (error case)
			User user1 = (User) deserialize(serializedFile);
			System.out.println(user1.getAge() + " has been deserialized.");
			

		} catch (Exception ex) {
			ex.printStackTrace(System.err);
		}
	}

}
