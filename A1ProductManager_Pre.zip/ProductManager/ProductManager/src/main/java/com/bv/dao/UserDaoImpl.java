package com.bv.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bv.connection.DBConnect;
import com.bv.loginmodel.User;

/**
 *  class  UserDaoImpl implements UserDao interface
 */
public class UserDaoImpl implements UserDao {
	
	 /**
	  * This is validate method for  user authentication
      * @param User u this is the reference variable of bean class
      * @return it returns boolean status
     */
	
	@Override
	public boolean validate(User u) {
	
	
			boolean status = false;
			String sql = "select * from User "
					+ "where username = ? and password = ?";
			
			Connection con = DBConnect.getConnection();
			System.out.println(con);
			try {
				if(null != con) {
					PreparedStatement pstmt = con.prepareStatement(sql);
					System.out.println(pstmt);
					if(null != pstmt) {
						pstmt.setString(1, u.getUsername());
						pstmt.setString(2,u.getPassword());
						ResultSet rs = pstmt.executeQuery();
						
						if(rs.next())
						status = true;
					}
				}
			
				
			
		

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return status;
	}
		
}
