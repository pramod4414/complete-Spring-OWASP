package com.bureauveritas.userdeserialized;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;



public class RequestProcessor {
	
	private static byte[] serialize(Object obj) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(baos);
		oos.writeObject(obj);
		byte[] buffer = baos.toByteArray();
		oos.close();
		baos.close();
		return buffer;
	}

	private static Object deserialize(byte[] buffer) throws IOException,
			ClassNotFoundException {
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);

		// We use SecureObjectInputStream instead of InputStream
		ObjectInputStream ois = new SecureObjectInputStream(bais);

		Object obj = ois.readObject();
		ois.close();
		bais.close();
		return obj;
	}

	public static void main(String[] args) {
		try {
			
			// Serialize an User instance
			byte[] serializedUser = serialize(new User("piyu", "piyu"));

			
			// Serialize a File instance
			byte[] serializedFile = serialize(new File("Pierre Ernst"));

			
			// Deserialize the User instance (legitimate use case)
			User user0 = (User) deserialize(serializedUser);
			
			System.out.println(user0.getName() + " has been deserialized.");

			
			// Deserialize the File instance (error case)
			User user1 = (User) deserialize(serializedFile);

		} catch (Exception ex) {
			ex.printStackTrace(System.err);
		}
	}

}
