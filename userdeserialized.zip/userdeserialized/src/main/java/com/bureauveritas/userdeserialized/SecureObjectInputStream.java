package com.bureauveritas.userdeserialized;

import java.io.IOException;
import java.io.InputStream;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;



public class SecureObjectInputStream extends ObjectInputStream  {
	

	public SecureObjectInputStream(InputStream inputStream)
			throws IOException {
		
		super(inputStream);
		
	}
	
	@Override
	protected Class<?> resolveClass(ObjectStreamClass desc) throws IOException,
			ClassNotFoundException {
		if (!desc.getName().equals(User.class.getName())) {
			throw new InvalidClassException(
					"Unauthorized deserialization attempt", desc.getName());
		}
		return super.resolveClass(desc);
	}
	
	
	

}
