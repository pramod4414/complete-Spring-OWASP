package com.javainuse.core;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MapStoreCheck {

	final static Map map = new HashMap();

	public static void storeToken(String token) {
		map.put(token, token);

	}

	public static boolean compareToken(String token) {
		map.put("test", "test");

		Iterator<Object> it = map.keySet().iterator();

		while (it.hasNext()) {

			it.next();
			if (map.containsKey(token)) {

				System.out.println("token is present your not allow to access");

				return true;

			}
			return false;
		}
		return false;

	}

}
