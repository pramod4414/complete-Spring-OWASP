package com.javainuse.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.javainuse.core.MapStoreCheck;

@RestController
@CrossOrigin()
public class LogoutController {

	@PostMapping("/exit")
	@ResponseBody
	public void exit(HttpServletRequest request, HttpServletResponse response) {

		System.out.println("Inside PostMapping Request");

		String authorization = request.getHeader("Authorization");

		if (authorization != null && authorization.contains("Bearer")) {
			String tokenId = authorization.substring("Bearer".length() + 1);
			System.out.println("Inside PM Request 1" + tokenId);

			MapStoreCheck.storeToken(tokenId);

		}

		new SecurityContextLogoutHandler().logout(request, null, null);
		try {

			response.sendRedirect(request.getHeader("referer"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
